%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  Fabrizio Clarelli - UiT - The Arctic University of Norway - 2018;  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all

tic

global_pg


global Pm 
global Pmq


q1  = 2500; %[2500; 2000]; %[500; 1000; 1200; 1400; 1600; 1800; 2000; 2200; 2400; 2500];
q1l = length(q1);

bx1 = [0.001; 200; 300; 600; 800; 1000; 1200; 1400; 1600; 1800];

R2_exp = zeros(1,q1l);

avd_exp = zeros(1,q1l);


var_amp_reg_1h

load Ampicillin_regoes  % (CFU/ml): Experimental data

dtr   = 10;
tr    = tmin:dtr:tmax;
trlen = length(tr);
tred  = dtr/dt;

vm = [0, 3, 6, 24, 48, 96, 128, 256]*10^-3;  % (g/l) .  Ampicillin concentration

nvm = length(vm);


Cexp = [Camp3_0(1:7);Camp3_3(1:7);Camp3_6(1:7);Camp3_24(1:7);Camp3_48(1:7);Camp3_96(1:7);Camp3_128(1:7);Camp3_256(1:7)]*10^3; % (cfu/l)   %exp. data are in(cfu/ml)


Cexpm = [Camp3_0(1:7),Camp3_3(1:7),Camp3_6(1:7),Camp3_24(1:7),Camp3_48(1:7),Camp3_96(1:7),Camp3_128(1:7),Camp3_256(1:7)]*10^3; % (cfu/l)


Ce0   = Camp3_0(1:7)*10^3;  % (cfu/l)  
Ce3   = Camp3_3(1:7)*10^3;
Ce6   = Camp3_6(1:7)*10^3;
Ce24  = Camp3_24(1:7)*10^3;
Ce48  = Camp3_48(1:7)*10^3;
Ce96  = Camp3_96(1:7)*10^3;
Ce128 = Camp3_128(1:7)*10^3;
Ce256 = Camp3_256(1:7)*10^3;


texp = tamp3(1:7)*3600; % time in (sec)

% vcf = [1, 0.5, 0.1, 0.05, 0.01, 0.001, 0.0001]; % [2, 5, 10, 50];
% ncf  = length(vcf);

BTqm = zeros(nvm,trlen);
Bqm  = zeros(nvm,ylen,trlen);
DTqm = zeros(nvm,trlen);
Dqm  = zeros(nvm,ylen,trlen);

r0  = 0.0004664; % 0.000403; % Estimated from the max growth exp Regoes;  maximum growth rate from Regoes paper Antimicrobial Agents


% Parameters  %%%  M = mol/l
kf  = 130;        %  data from Pia and me Plos comp. biology ref 25;
kr  = 1*10^(-4);  % data from Pia and me Plos comp. biology ref 25;
dr0 = 2.9*10^(-3)+r0; % (1/sec);   2.9*10^(-3) maximum death rate from Regoes paper Antimicrobial Agents
shs = 5;      % death shape
ths = 0.99;      % death rate threshold


xmic = 1; % check if the exp data are right  %16*3*10^-3=48*10^-3

kf1 = kf/(Na*Vtot);

K   = 1.40*10^12;  % (CFU/l) .  carrying capacity of bacteria

Bin   = Cexp(1)*Vtot; %10^5;  % Initial number of bacteria to estimate an apparent volume
Din   = 0;

%%%%%%%%%%%%%%%%%
% Growth rates
    
rq     = zeros(ylen,1);
rq(:)     = r0; %*ffreeq(:);
 
 
 
    
%%%%%%%%%%%%%%%%
% Death rates:

drq       = zeros(ylen,1);
drq1      = zeros(ylen,1);


nc1 = q1/dy+1; % n. of points where is q1 = y(nc1);
nc2 = ylen - nc1;
b1=0.0023; % right one is:0.0023;
c1=dr0/(exp(b1*q1)-1); % q1 is the point where we want to arrive with the maximum dr0.
drq1(1:nc1) = c1*(exp(b1*y(1:nc1))-1);

drq(nc2+1:end)=drq1(1:nc1); %c1*(exp(b1*(y(1:nc2)-q1(j)))-1);
drq(1:nc2) = 0;
%drq(:)    = dr0./(1+exp(-shs*(y(:)/ni-ths)));
drq(end)  = dr0;
 

parfor i=1:nvm

    mic   = vm(i); % (g/l) 
    Amic  = mic/muf*Na*Vtot;  % # of drug's molecules with a mic conc. in Bin number of bacteria.
    
    Ain   = xmic*Amic; 
    Cain  = xmic*mic;


    
    % Higher Deltax, i.e. dx>1
    Bq     = zeros(ylen,trlen);
    B0q    = zeros(ylen,1);
    B1q    = zeros(ylen,1);
    BTq    = zeros(1,trlen);
    
    Dq     = zeros(ylen,trlen);
    D0q    = zeros(ylen,1);
    D1q    = zeros(ylen,1);
    DTq    = zeros(1,trlen);

    Aq     = zeros(1,trlen);
    Caq    = zeros(1,trlen);
    Ca1q   = zeros(1,trlen);

    vrq    = zeros(ylen,trlen);
    vr0q   = zeros(ylen,1);
    vr1q   = zeros(ylen,1);

    vfq    = zeros(ylen,trlen);
    vf0q   = zeros(ylen,1);
    vf1q   = zeros(ylen,1);

    

    % Initial condition:
    % dy initial conditions
    B0q(1)   = Bin/dy; %*(1-x(:)/ni); %Bin;  % #mol/liter.  % t=0, all bacteria with free target molecules. 
    D0q(1)   = Din;
    % Bq(1,1)  = B0q(1);
    %si       = 50;
    %B0q(:)   = Bin/(125.3314)*exp(-(y(:)-ni/4).^2/(2*si^2));
    Bq(:,1)  = B0q(:);
    Bqall    = dy*sum(Bq(:,1));
    BTq(1)   = dy*sum(B0q(:));
    
    Dq(:,1)  = D0q(:);
    Dqall    = dy*sum(Dq(:,1));
    DTq(1)   = dy*sum(D0q(:));

    A0q      = Ain;
    Aq(1)    = Ain;  
    Ca0q     = Cain;
    Caq(1)   = Cain;  

    vr0q(:)  = -kr*y(:);
    vrq(:,1) = vr0q(:);

    vf0q(:)  = kf1*A0q*(ni-y(:));
    vfq(:,1) = vf0q(:);
    
   

    %%%%%%%%%%%
    % check numerical stability!!

    cr     = muf/(Na*Vtot);

    mm = max([dt*r0*(K-Bqall)/K,dt*kf1*A0q*dy*sum((ni-y(:)).*B0q(:))/Ain,dt*kr*dy*sum(y(:).*B0q(:))/Ain,dt/dy*kf1*A0q*ni,dt/dy*kr*ni,2*dt*dy*r0,dt*dr0]);

    if mm < 0.5
    %     mm
    %     'numerical stab. ok'
    else
        'Numerical Instability Error; mm is:'
        mm
        kf
        kr
        X0
        %break
    end


    Pmuq = triu(Pmq(:,:));

    Iq  = 0.1*ones(ylen,ylen);
    Iuq = triu(Iq(:,:));


    for n=1:tlen-1 %72000%tlen-1  
    
    
        %%%%%% q version %%%%%%%
        Bqall   = dy*sum(B0q(:));

        A1q     = A0q - dt*kf1*A0q*dy*sum((ni-y(:)).*B0q(:)); % no free antibiotics + dt*kr*dy*sum(y(:).*B0q(:));  % OK!!
        Ca1q    = A1q*muf/(Vtot*Na); % ok!  % Ca0 - dt*cr*kf/muf*Ca0*sum((ni-x(:)).*B0(:)) + dt*cr*kr*dx*sum(x(:).*B0(:));

        vr1q(1) = 0;
        vf1q(1) = kf1*A1q*(ni-y(1));

        B1q(1)  = B0q(1) - dt/dy*kf1*A0q*(ni-y(1))*B0q(1) + dt/dy*kr*y(2)*B0q(2) - dt*rq(1)*B0q(1)*(K-Bqall)/K +...
                2*dt*(Pmuq(1,:)*(rq(:).*B0q(:)) )*(K-Bqall)/K - dt*drq(1)*B0q(1);

        B1q(2:ylen-1) = B0q(2:ylen-1) - dt/dy*(vf0q(2:ylen-1).*B0q(2:ylen-1) - vf0q(1:ylen-2).*B0q(1:ylen-2)) -...
            dt/dy*( vr0q(3:ylen).*B0q(3:ylen) - vr0q(2:ylen-1).*B0q(2:ylen-1) ) -...
            dt*rq(2:ylen-1).*B0q(2:ylen-1)*(K-Bqall)/K + 2*dt*(Pmuq(2:ylen-1,:)*(rq(:).*B0q(:)) )*(K-Bqall)/K - dt*drq(2:ylen-1).*B0q(2:ylen-1);

        vr1q(2:ylen-1) = -kr*y(2:ylen-1);
        vf1q(2:ylen-1) = kf1*A1q*(ni-y(2:ylen-1));

        vr1q(ylen) = -kr*y(ylen);
        vf1q(ylen) = 0; % from  kf1*A(n+1)*(ni-x(xlen));

        B1q(ylen)  = B0q(ylen) + dt/dy*kf1*A0q*(ni-y(ylen-1))*B0q(ylen-1) - dt/dy*kr*y(ylen)*B0q(ylen) -...
            dt*rq(ylen)*B0q(ylen)*(K-Bqall)/K + 2*dt*Pmuq(ylen,ylen)'.*rq(ylen).*B0q(ylen)*(K-Bqall)/K - dt*drq(end)*B0q(end);
        
        D1q(:) = D0q(:) + dt*drq(1:ylen).*B0q(1:ylen);

        
        if mod(n-1,tred)==0
            m = (n-1)/tred;
            Bq(:,m+1)  = B0q(:);
            Dq(:,m+1)  = D0q(:);
            Aq(m+1)    = A0q; %Ca(m+1)/muf*Na*Vtot;
            Caq(m+1)   = Aq(m+1)*muf/(Na*Vtot);
            vrq(:,m+1) = vr0q(:);
            vfq(:,m+1) = vf0q(:);
        else
        end

        B0q  = B1q;
        D0q  = D1q;
        Ca0q = Ca1q;
        A0q  = A1q;
        vr0q = vr1q;
        vf0q = vf1q;


    end

    
    %%%%
    Bq(:,end)  = B1q(:);
    Bqall      = dy*sum(B1q(:));
    BTq(:)     = dy*sum(Bq(:,:),1);
    
    Dq(:,end)  = D1q(:);
    Dqall      = dy*sum(D1q(:));
    DTq(:)     = dy*sum(Dq(:,:),1);

    Caq(end)   = Ca1q;
    Aq(end)    = Caq(end)/muf*Na*Vtot;
    vrq(:,end) = vr1q(:);
    vfq(:,end) = vf1q(:);

    

    BTqm(i,:)  = BTq(:);
    Bqm(i,:,:) = Bq(:,:);
    
    DTqm(i,:)  = DTq(:);
    Dqm(i,:,:) = Dq(:,:);

    
end

CBq = BTqm/Vtot;

%ts=[tr(1),tr(3),tr(5),tr(7),tr(9),tr(11),tr(13),tr(17),tr(21),tr(25),tr(31),tr(37),tr(43),tr(49),tr(55),tr(trlen)];

cs = zeros(1,nvm*trlen);

for i=1:nvm
    h1 = (i-1)*trlen+1;
    hl = i*trlen;
    cs(h1:hl) = CBq(i,:);
end


%yexp = Cexp; %[Cexp(1);Cexp(3:end)];

% res = fitlm(log(cs),log(Cexp));
% 
% R2  = res.Rsquared.Ordinary;
% 
% pm = res.RMSE; % root mean squared error
% 
% 
% % SStot = sum((yexp(:)-ym).^2);
% % SSres = sum((yexp(:)-yhat(:)).^2);
% % 
% % R2 = 1- SSres/SStot;
% 
% num = length(yexp); %length(Cexp);
% %out = sum( sqrt((cs(:) - Cexp(:)).^2)./Cexp(:) )*1/num; %C21
% 
% if R2<1
%     out = 1-R2; %sum( sqrt((yhat(:) - yexp(:)).^2)./yexp(:) )*1/num; %C21
% else
%     out = 1-3*R2;
% end
% 
% avd = sum( sqrt((cs(:) - Cexp(:)).^2)./Cexp(:) )*1/num; %C21
% 
% ma = max( sqrt((cs(:) - Cexp(:)).^2)./Cexp(:) );
% 
% v1=[R2,avd,X0];
% 
% if R2>0.6
%     fprintf(fileIDg,'%12.8f %12.8f %12.8f %12.8f\r\n',v1);
% else
%     fprintf(fileIDb,'%12.8f %12.8f %12.8f %12.8f\r\n',v1);
% end
% 
% R2_exp(j) = R2;
% 
% avd_exp(j) = avd; 
% 
% fclose(fileIDg);
% fclose(fileIDb);


w = 10^-3;
trm=tr/60;
texpm=texp/60;
figure;semilogy(trm,w*CBq(1,:),'c',texpm,w*Ce0,'c*',trm,w*CBq(2,:),'m',texpm,w*Ce3,'*m',trm,w*CBq(3,:),'y',texpm,w*Ce6,...
'y*',trm,w*CBq(4,:),'r',texpm,w*Ce24,'r*',trm,w*CBq(5,:),'g',texpm,w*Ce48,'g*',trm,w*CBq(6,:),'b',texpm,w*Ce96,'b*',...
trm,w*CBq(7,:),'k',texpm,w*Ce128,'k*',trm,w*CBq(8,:),'c',texpm,w*Ce256,'c*','LineWidth',2)
xlabel('Time (min)') 
ylabel('CFU/mL') 



% Cx0=CBq(1,:);
% Cx2=CBq(2,:);
% Cx3=CBq(3,:);
% Cx3_1=CBq(4,:);
% Cx3_2=CBq(5,:);
% Cx3_3=CBq(6,:);
% Cx3_4=CBq(7,:);
% Cx3_5=CBq(8,:);
% Cx3_6=CBq(9,:);
% Cx3_7=CBq(10,:);
% Cx3_8=CBq(11,:);
% Cx3_9=CBq(12,:);
% Cx4=CBq(13,:);
% Cx5=CBq(14,:);
% Cx6=CBq(15,:);
% Cx8=CBq(16,:);
% Cx10=CBq(17,:);
% Cx12=CBq(18,:);
% Cx15=CBq(19,:);
% Cx24=CBq(20,:);
% Cx48=CBq(21,:);
% Cx96=CBq(22,:);
% Cx128=CBq(23,:);
% Cx256=CBq(24,:);

%vm = [0, 2, 3, 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 3.9, 4, 5, 6, 8, 10, 12, 15, 24, 48, 96, 128, 256]*10^-3;

% LCx0=log10(Cx0);
% LCx2=log10(Cx2);
% LCx3=log10(Cx3);
% LCx3_1=log10(Cx3_1);
% LCx3_2=log10(Cx3_2);
% LCx3_3=log10(Cx3_3);
% LCx3_4=log10(Cx3_4);
% LCx3_5=log10(Cx3_5);
% LCx3_6=log10(Cx3_6);
% LCx3_7=log10(Cx3_7);
% LCx3_8=log10(Cx3_8);
% LCx3_9=log10(Cx3_9);
% LCx4=log10(Cx4);
% LCx5=log10(Cx5);
% LCx6=log10(Cx6);
% LCx8=log10(Cx8);
% LCx10=log10(Cx10);
% LCx12=log10(Cx12);
% LCx15=log10(Cx15);
% LCx24=log10(Cx24);
% LCx48=log10(Cx48);
% LCx96=log10(Cx96);
% LCx128=log10(Cx128);
% LCx256=log10(Cx256);
% 

% Dr1    =  [0.001000; 3.0000; 6.0000; 24.0000; 48.0000; 96.0000; 128.0000; 256.0000];
% 
% yexp   = [0.7290; -0.0620; -0.5240; -0.8730; -2.1430; -3.3300; -2.9200; -3.3400];
% % or
% 
% %%%  40 min.
% 
% % experimental linear fit in 40 mins. 1st point free (not fixed initial condition)
% yexp40 = [0.63; -0.21; -0.45; -0.54; -1.55; -4.08; -4.29; -4.72];
% 
% %yexp60 = 
% 
% %%%  60 min.
% 
% % experimental linear fit in 40 mins. 1st point free (not fixed initial condition)
% yexp40E = [0.54; -0.64; -0.72; -1.13; -1.45; -3.89; -4.34; -4.50];
% 
% %yexp60E = 
% 
% %a=(log10(Ce3r(end))-log10(Ce3r(1)))/(tamp3(5)-tamp3(1));
% 
% NG10 = zeros(1,nvm);
% 
% for j=1:nvm
%     NG10(j) = (log10(CBq(j,end))-log10(CBq(j,1)))/1; % 1/h => scaled log10 
% end
% 
% te = (trlen-1)/2;
% 
% NGexp10 = zeros(1,length(vm));
% for j=1:nvm
%     NGexp10(j) = (log10(CBq(j,end))-log10(CBq(j,te)))*3600/(tr(end)-tr(te)); % 1/h => scaled log10 
% end
% 
% Ngs60 = [0.729; 0.647; 0.450; 0.192; 0.165; 0.138; 0.110; 0.0829; 0.0555; 0.0280; 0.00064; -0.0157;...
%     -0.0541; -0.0815; -0.35; -0.605; -1.064; -1.453; -1.779; -2.173; -2.915; -3.676; -4.097; -4.205; -4.369];
% 
% Drl   = [0, 1, 2, 3, 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 3.9, 4, 5, 6, 8, 10, 12, 15, 24, 48, 96, 128, 256]'; % (mg/l) NOT g/l like vm!!!
% 
% z1=zeros(1,nvm);
% 
% figure;semilogx(Dr1,yexp,vm*10^3,NG10,vm*10^3,NGexp10,vm*10^3,z1)

%save 'Ampicillin_paper18_aroundMIC_mic_drq_exp'

toc

