


% time
day1  = 3600*24;
hour1 = 3600;
TL    = 1*hour1; %18*hour1; % (sec),  last of simulation
tmin  = 0;
tmax  = TL;  % sec, 1 day = 3600*24 sec 
%time  = linspace(tmin,tmax,1000001); %linspace(0,Tmax,100001);
dt    = 0.02; %0.001 %0.08
t     = tmin:dt:tmax;
tlen  = length(t);

% time reduced

dtr   = 1*60;
tr    = tmin:dtr:tmax;
trlen = length(tr);
tred  = dtr/dt;

% The variable x means the real number of occupied places (number of bound target)
ni    = 2500; %2000;  %  number of target molecule for each bacterium
xref  = ni;

XL    = ni;
xmin  = 0;  
xmax  = XL;
fx    = 1;
xelem = fx*ni+1;
x     = linspace(xmin, xmax,xelem);
dx    = x(4)-x(3);
xlen  = length(x);

fy    = 0.1;
dy    = dx/fy;
ymin  = 0;
ymax  = ni;
y     = ymin:dy:ymax;
ylen  = length(y);
% x0    = linspace(xmin, xmax,ni+1);
% dx0   = x0(4)-x0(3);
% x0len = length(x0);

resc   = 1;
% non-dim variable
ximin  = 0;  
ximax  = 1;
nelem  = ni/resc+1;
xi     = linspace(ximin, ximax,nelem);
dxi    = xi(4)-xi(3); %just for precision
xilen  = length(xi);


%%%%%%%%%%% From Presentation MeetingGatesGrant2015_05_18 %%%%%%%%%%%%%%%%%
% kd values: affinity
% Norflox.  kd = 1.66*10^(-6) [M]
% Ciprofl.  kd = 1.84*10^(-6) [M]
% Ofloxac.  kd = 2.46*10^(-6) [M]
% Pefloxa.  kd = 9.00*10^(-6) [M]
% Oxol.ac.  kd = 1.00*10^(-5) [M]
% Pipe.ac.  kd = 1.02*10^(-4) [M]
% Nali.ac.  kd = 2.24*10^(-4) [M]

% constants

Na    = 6.022*10^23; % Avogadro constant
mua   = 349.40476;   % g/mol;    Molar mass Ampicillin;    Conc = mua*Ae;
mut   = 444.435;     % g/mol;    Molar mass Tetracycline   mic esc. coli   128 mug/ml
muc   = 331.346;     % g/mol   Molar mass Ciprofloxacin
mup   = 303.32;      % g/mol  Molar mass  Pipemidic acid

% Choice of drugs:
muf   = mua;

Vtot  = 0.2*10^(-3); % l or (dm^3),  Volume of Soren experiments

R1    = 0.75/2*10^-5; %(dm) radius of cylinder
h     = 2.47*10^-5;   % (dm)  length of cylinder
% S/V = 2*(1/R1+1/h); assuming to have a cylinder!!!
AV    = 2*(1/R1+1/h); % dm^-1; it is A/V surface over volume of each bacterium
Vi    = 10^(-15);  % dm^3

hatp  = 2*10^(-11)*10; % dm/sec  from => 2*10^(-11) (m/s) from Pia Kinetic... supplemental pag 12
p     = hatp*AV;  % 1/sec;
pn    = TL*p;  % non-dimensionalization of p


%kr    = 0.0184; %0.184; % 1/sec %%% Ciproflox. 0.102; %%% pipemidic acid 0.184; %%% (1/sec) %%% from 10^-1 to 10^-3; 
%krn   = TL*kr; % non-dimensionalization of kr
%kf    = 1*10^4; % try to see what happens with 1/20 wild type!! %3*10^5; %(M^-1*sec^-1); Tetracycline. => 130 +-1, (Ampicillin) 1/(mol/liter*sec)
%kf    = 10^3;  % ciprofloxacin
%kf1   = kf/(Na*Vi);  % it is true for 1 bacterium!!!!!
%kfc   = kf/muc;
%kfp   = kf/mup;

%kfn   = TL*kf;  % % non-dimensionalization of kf
%kd    = kr/kf;  % mol/liter  %%% Ciproflox. kd=1.84*10^-6;(M) Pipemidic acid kd=1.02*10^-4; (M)
%kdn   = krn/kfn;

%%%%% Important %%%%
%fc    = 0.05;  % threshold given by the percentage reached by bound target molecules
fft   = 0; %1-fc;  % threshold given by the percentage of free target molecules

%b ffree = T(n+1)/(T(n+1) + AT(n+1));  % free target molecules/total target molecules

% duplication time e. coli: 20 min 
% td    = 21*60; % (sec); Duplication time
% r0    = 1*log(2)/td*(1); % optimal growth factor

% Optimal death rate: 
%tdt   = 30*60; % (sec);
%dr0   = -log(0.01)/3600; % maximum death rate from 1 to 10^-2 in 1 hours

%%%%%%% Initial conditions:

%load cipro_62 % C62 t62   %try_cipro_12 %Cm12 t back factor RCipro_0_015625 %'RCipro_all' % 
%RB    = RCipro_0_015625(:,2); %RCipro_0_03125(:,2); % RCipro_0_0625(:,2); % RCipro_0_125(:,1)'; % 1 is day 18;

%ba    = RB(1) - Bin/factor; % background estimated from
%Bexp  = C; %(RB(:)-ba)*factor;  % experimental data rescaled to cfu in 0.2 ml with Bin initial number of bacteria;

% mic   = 0.0625*10^(-3); % (g/liter) %0.0625*10^(-3); %0.125*10^(-3); % 0.015625*10^(-3); % (g/liter)    # Quinolones real MIC 0.5 mg/l;  3.6001*10^-5;  %fc*kd/(1-fc); % 3.6001*10^-5;  % mol/liter    %fc*kd/(1-fc);  % ??????? Is it true???
% Amic  = mic/muf*Na*Vtot;  % # of drug's molecules with a mic conc. in Bin number of bacteria.
%%%% xmic for sensitivity: 0.0039;  0.0156; 0.0312; 0.0625; 0.125; 0.25;
% xmic  = 1; %0.0625; %0.00195; %0.0039; %0.0078; %0.0312; %0.0078; %0.0156; %0.0312; %0.0625; %0.125; %0.1; % 0.8;
% Ain   = xmic*Amic; 
% Cain  = xmic*mic;

int   = 24*3600; %(sec) time interval 
npmax = fix(t(end)/int);  % number of interval contained in time
pi    = round(int/dt);  % time points (-1) in int


