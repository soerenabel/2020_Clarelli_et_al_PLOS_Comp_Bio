
function global_pg


% The variable x means the real number of occupied places (number of bound target)
ni    = 2500; %2000;  %  number of target molecule for each bacterium
xref  = ni;

XL    = ni;
xmin  = 0;  
xmax  = XL;
fx    = 1;
xelem = fx*ni+1;
x     = linspace(xmin, xmax,xelem);
dx    = x(4)-x(3);
xlen  = length(x);

fy    = 0.1;
dy    = dx/fy;
ymin  = 0;
ymax  = ni;
y     = ymin:dy:ymax;
ylen  = length(y);

global Pm Pmq


Pm     = zeros(xlen,xlen);
Pmq    = zeros(ylen,ylen);


for j=1:xlen    
    for q=1:j
        Pm(q,j)  = dx*hgexth(x(q),2*ni,x(j),ni);
    end
end
% 
% Pmu = triu(Pm(:,:));
% 
% I  = 0.1*ones(xlen,xlen);
% Iu = triu(I(:,:));
% 



for j=1:ylen-1    
    for q=1:j
        in=(q-1)*dy+1;
        fi=q*dy;
        %Pmq(q,j)  = hgexth(y(q),2*ni,y(j),ni);  % we have to redifine the total number of elements with a different step
        Pmq(q,j)  = sum(Pm(in:fi,dy*j)); %hgexth(y(q),2*ni,y(j),ni);
    end
end

for q=1:250 
    in=(q-1)*dy+1;
    fi=q*dy;
    Pmq(q,251)  = sum(Pm(in:fi,2501)); %hgexth(y(q),2*ni,y(j),ni);
end


end