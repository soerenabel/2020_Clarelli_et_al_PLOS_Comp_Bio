### set your work directory
setwd("/Users/Pia/Dropbox/WriteResistancePaper/IncludeMerete/CodeForSubmissionClarelli/CodeFigure1")
###Import Data  from literature on MIC  and KD


Quinolones=read.csv("QuinolonesLiteratureMol.csv")

## species names
organisms=colnames(Quinolones[,3:(ncol(Quinolones)-1)])

## quinolone names
antibiotics=Quinolones[,1]

## quinolone affinities
KDs=Quinolones[,"KD"]

### create matrix that holds data on linear regression for each organism

FitMatrix=matrix(nrow=length(organisms),ncol=3,dimnames=list(organisms,c("p","slope","adj.R2")))


#### quartz() is for MAc computers. Use windows() on a PC
quartz(height=6,width=11)
par(mfrow=c(3,4),mar=c(4,4,3,4))


###Prepare plot
plot(c(0,1),c(0,1),type="n",bty="n",xaxt="n",yaxt="n",xlab="",ylab="",main="quinolones by affinity")
text(0.5,seq(0.95,0,length=7),labels=paste(antibiotics,"=",format(10^KDs,digits=1,scientific=T),"[M]"))

for(i in 1:length(organisms)){
	organism=organisms[i]

	MIC=log10(Quinolones[,organism])



	regression=lm(MIC~KDs)

	

	summary=summary(regression)

	p=summary$coeff[2,4]
	R=summary$adj.r.squared
	slope=summary$coeff[2,1]


	FitMatrix[organism,]=c(p,slope,R)
	
	plot(KDs,MIC,main=paste(organism,", R2=",signif(R,2),", p=",signif(p,2),sep=""),xlab="log10(KD) quinolone [M]",ylab="log10(MIC50) [M]",pch=16,col=2,ylim=c(-7.3,-4.6),xlim=c(-6.5,-3.5))

	#text(KDs,0.9*MIC)
	
	abline(regression)
	

}


