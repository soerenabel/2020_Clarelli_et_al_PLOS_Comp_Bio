% Hypergemetric probability extended (to real) function

%Y = hygepdf(X,M,K,N) computes the hypergeometric pdf at each of the values in X using the corresponding size of the population, 
% M, number of items with the desired characteristic in the population, K, and number of samples drawn, N. X, M, K, and N can be vectors, matrices, 
% or multidimensional arrays that all have the same size. A scalar input is expanded to a constant array with the same dimensions as the other inputs.
% The parameters in M, K, and N must all be positive integers, with N ? M. The values in X must be less than or equal to all the parameter values.

% x # of white balls drawn;  m total # of balls (total population); k total  # of white balls; n total # of drawn balls

% Generalization of hygepdf(X,M,K,N) for discrete numbers

function phg = hgexth(x,m,k,n) 

phg =  exp( ( gammaln(k+1)-(gammaln(x+1)+gammaln(k-x+1)) + gammaln(m-k+1)-( gammaln(n-x+1) + gammaln(m-k-(n-x)+1) ) ) - ( gammaln(m+1) - (gammaln(n+1)+gammaln(m-n+1)) )  );
