%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  Fabrizio Clarelli - UiT - The Arctic University of Norway - 2018;  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%% Choose DIMENSIONS %%%%%%%%%%%%%%%%%%%%%%%
% dm (liter for volume), sec, g,


clear all


varnew_pde_merete  %variables  % call all constants and variables

load('merete_kcurves.mat')
load('MT_3_cases.mat')

global Pm 
global_pgc

kr  = 30*10^(-5);  % 1/sec . %kr = X0(2)*10^(-5);

dr0 = 0.005826;    % 1/sec   0.005826 - IC 95%:(-0.01428, 0.02593) - Exp. Fit C8 forced 1st point with the aver. of the 3 exp. points
r0  = 0.0002416;   % 1/sec  0.0002416 - IC 95%:(0.0002265, 0.0002567) - Exp. Fit C0 forced 1st point with the aver. of the 3 exp. points


kf  = 3.2098*10^3;
br  = 0.0459; % coefficient of replication exponential from 10^-2 to 1
bd  = 0.0547; % coefficient of death rate exponential from 10^-2 to 1

% 
% bd  = X0(4);  % death rate shape; ranges between 0.05-2; dr=Dr0/( 1 + exp(-be*(x-x0)) ); 
% x0d = X0(5);  % threshold death rate; ranges between 5-100

kf1 = kf/(Na*Vtot);

texp  = tmexp; %sec


Drug1 = Dm*10^(-3); % g/l   %  [MC,MC2,MC3,MC4,MC5,MC6,MC7];
vm    = Drug1; % g/l   %  [0.5*0.0123, 0.0123, 2*0.0123, 3*0.0123, 5*0.0123, 10*0.0123, 20*0.0123]*10^-3; % g/l
nvm   = length(vm);

% experimental data
Cexp(:,:) = MT(:,:)*10^3; %cfu/l ; exp MF is in cfu/ml;

% Initial conditions
Bin = (MTav(:,1)*10^3)*Vtot;  % cfu/L*Vol - Average of the 3 initial experimental points  
    
 
%%%%%%%%%%%%%%%%
%%% Death rate
%%%%%%%%%%%%%%%

dr       = zeros(xlen,1);
ad       = dr0/(exp(bd*x(end))-1);
dr(:)    = ad*(exp(bd*x(:))-1);
dr(1:6)  = 0;
dr(end)  = dr0; %dr0old;    


%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Growth rate %%% Exponential 
%%%%%%%%%%%%%%%%%%%%%%%%%

r          = zeros(xlen,1);
ar         = r0/( 1 - exp(-br*x(end)) );
cr         = r0 - ar;
r(2:end)   = ar*exp(-br*x(2:end)) + cr; %
r(95:end)  = 0;
r(1)       = r0;

%%%%%%%%%%%%%%%%%%
ATm  = zeros(nvm,trlen);
BTm  = zeros(nvm,trlen);
Bm   = zeros(nvm,xlen,trlen);


%parfor i=1:nvm
for i=1:nvm
    
%     poolobj = gcp;
%     addAttachedFiles(poolobj,{'varnew_pde_merete.m'})

    % Initial condition:
    mic   = vm(i); % (g/l) 
    Amic  = mic/muf*Na*Vtot;  % # of drug's molecules with a mic conc. in Bin number of bacteria.
    
    Ain   = Amic; 
    Cain  = mic;
    
    
    B     = zeros(xlen,trlen);
    BT    = zeros(1,trlen);
    B0    = zeros(xlen,1);
    B1    = zeros(xlen,1);

    A     = zeros(1,trlen);
    Ca    = zeros(1,trlen);

    vr    = zeros(xlen,trlen);
    vr0   = zeros(xlen,1);
    vr1   = zeros(xlen,1);

    vf    = zeros(xlen,trlen);
    vf0   = zeros(xlen,1);
    vf1   = zeros(xlen,1);

   %%%%%%%%
    
    B0(1)   = Bin(i); %*(1-x(:)/ni); %Bin;  % #mol/liter.  % t=0, all bacteria with free target molecules.     

    B(1,1)  = B0(1);
    Ball    = sum(B(:,1));
    BT(1)   = sum(B0(:));

    A0      = Ain;
    A(1)    = Ain;  
    Ca0     = Cain;
    Ca(1)   = Cain;  

    vr0(:)  = -kr*x(:);
    vr(:,1) = vr0(:);

    %kf2     = kf/(Na*Vi*Ball);

    vf0(:)  = kf1*A0*(ni-x(:));
    vf(:,1) = vf0(:);
    
    
    cr     = muf/(Na*Vtot);

    mm = max([dt*r0*(K-Ball)/K,dt*kf1*vm(i)*sum((ni-x(:)).*B0(:))/Ain,dt*kr*dx*sum(x(:).*B0(:))/Ain,dt/dx*kf1*A0*ni,dt/dx*kr*ni,2*dt*dx*r0,dt*dr0]);

    if mm < 0.5
    %     mm
    %     'numerical stab. ok'
    else
        'Numerical Instability Error; mm is:'
        mm
        kf
        kr
        X0
        %break
    end



%     for j=1:xlen    
%         for q=1:j
%             Pm(q,j)  = hgexth(x(q),2*ni,x(j),ni);
%         end
%     end

    Pmu = triu(Pm(:,:));
 

    I  = 0.1*ones(xlen,xlen);
    Iu = triu(I(:,:));

    
    
    for n=1:tlen-1  

            Ball  = sum(B0(:));

            % discrete
            A1  = A0 - dt*kf1*A0*sum((ni-x(:)).*B0(:)) + dt*kr*sum(x(:).*B0(:));  
            Ca1 = A1*muf/(Vtot*Na); % ok!  % Ca0 - dt*cr*kf/muf*Ca0*sum((ni-x(:)).*B0(:)) + dt*cr*kr*dx*sum(x(:).*B0(:)); 

            vr1(1) = 0;
            vf1(1) = kf1*A1*(ni-x(1));
            B1(1)  = B0(1) - dt*vf0(1)*B0(1) + dt*kr*x(2)*B0(2) - dt*r(1)*B0(1)*(K-Ball)/K +...
                2*dt*dx*sum( Pm(1,1:end)'.*r(1:end).*B0(1:end) )*(K-Ball)/K - dt*dr(1)*B0(1);

        %     Bq1(1) = Bq0(1) - dt*vf0(1)*Bq0(1) + dt*kr*x(2)*Bq0(2) - dt*r(1)*Bq0(1)*(K-Bqall)/K +...
        %         2*dt*dx*sum( Pm(1,1:end)'.*r(1:end).*Bq0(1:end) )*(K-Bqall)/K - dt*dr(1)*Bq0(1);

            %%%%%%%%%%%

            B1(2:xlen-1)  = B0(2:xlen-1) - dt/dx*(vf0(2:xlen-1).*B0(2:xlen-1) - vf0(1:xlen-2).*B0(1:xlen-2)) -...
                dt/dx*( vr0(3:xlen).*B0(3:xlen) - vr0(2:xlen-1).*B0(2:xlen-1) ) -...
                    dt*r(2:xlen-1).*B0(2:xlen-1)*(K-Ball)/K + 2*dt*dx*( Pmu(2:xlen-1,:)*(r(:).*B0(:)) )*(K-Ball)/K - dt*dr(2:xlen-1).*B0(2:xlen-1); 

                %dt*r(2:xlen-1).*B0(2:xlen-1)*(K-Ball)/K + 2*dt*r(2:xlen-1).*B0(2:xlen-1)*(K-Ball)/K - dt*dr(2:xlen-1).*B0(2:xlen-1);
                    % % dt*kf*Ad(n)*(ni-x(j))
        %     for j=2:xlen-1 
        %         Bq1(j)  = Bq0(j) - dt/dx*(vf0(j)*Bq0(j)-vf0(j-1)*Bq0(j-1)) - dt/dx*( vr0(j+1)*Bq0(j+1) - vr0(j)*Bq0(j) ) -...
        %             dt*r(j)*Bq0(j)*(K-Bqall)/K + 2*dt*dx*sum( Pm(j,j:end)'.*r(j:end).*Bq0(j:end) )*(K-Bqall)/K - dt*dr(j)*Bq0(j);  % dt*kf*Ad(n)*(ni-x(j))       
        % %         vr1(j) = -kr*x(j);
        % %         vf1(j) = kf/mu*Ca1*(ni-x(j));
        %     end

            vr1(2:xlen-1) = -kr*x(2:xlen-1);
            vf1(2:xlen-1) = kf1*A1*(ni-x(2:xlen-1));

            %%%%%%%%%%%

            %%%%%%%%%%
        %     for j=2:xlen-1 
        %         B1(j)  = B0(j) - dt/dx*(vf0(j)*B0(j)-vf0(j-1)*B0(j-1)) - dt/dx*( vr0(j+1)*B0(j+1) - vr0(j)*B0(j) ) -...
        %             dt*r(j)*B0(j)*(K-Ball)/K + 2*dt*dx*sum( Pm(j,j:end)'.*r(j:end).*B0(j:end) )*(K-Ball)/K - dt*dr(j)*B0(j);  % dt*kf*Ad(n)*(ni-x(j))       
        %         vr1(j) = -kr*x(j);
        %         vf1(j) = kf/muf*Ca1*(ni-x(j));
        %     end
            %%%%%%%%%%%%%%

            vr1(xlen) = -kr*x(xlen);
            vf1(xlen) = 0; % from  kf1*A(n+1)*(ni-x(xlen));
            B1(xlen)  = B0(xlen) + dt*kf1*A0*B0(xlen-1) - dt*kr*x(xlen)*B0(xlen) -...
                dt*r(xlen)*B0(xlen)*(K-Ball)/K + 2*dt*dx*Pm(xlen,xlen)'.*r(xlen).*B0(xlen)*(K-Ball)/K - dt*dr(end)*B0(end);

        %     Bq1(xlen) = Bq0(xlen) + dt*kf/muf*Ca0*Bq0(xlen-1) - dt*kr*x(xlen)*Bq0(xlen) -...
        %         dt*r(xlen)*Bq0(xlen)*(K-Bqall)/K + 2*dt*dx*Pm(xlen,xlen)'.*r(xlen).*Bq0(xlen)*(K-Bqall)/K - dt*dr(end)*Bq0(end);

            if mod(n-1,tred)==0
                m = (n-1)/tred;
                B(:,m+1)  = B0(:);
                %Bq(:,m+1) = Bq0(:);
                A(m+1)    = A0; %Ca(m+1)/muf*Na*Vtot;
                Ca(m+1)   = A(m+1)*muf/(Na*Vtot);
                vr(:,m+1) = vr0(:);
                vf(:,m+1) = vf0(:);
            else
            end


            B0  = B1;
            %Bq0 = Bq1;
            Ca0 = Ca1;
            A0  = A1;
            vr0 = vr1;
            vf0 = vf1;

            


    end


    % Eint = interp1(texp,Bexp,td,'pchip'); %interpolation experimental data

    B(:,end)  = B1(:);
    Ball      = sum(B1(:));
    BT(:)     = sum(B(:,:),1);

    % Bq(:,end) = Bq1(:);
    % Bqall     = sum(Bq1(:));
    Ca(end)   = Ca1;
    A(end)    = Ca(end)/muf*Na*Vtot;
    vr(:,end) = vr1(:);
    vf(:,end) = vf1(:);
    
    BTm(i,:)  = BT(:);
    Bm(i,:,:) = B(:,:);
    ATm(i,:)  = A(:);
    
end
    
    
CB  = BTm/Vtot;

ep  = [1,1201,2401,3601,4801,6001,7201]; % with dtr = 1
% Bn(:,end)  = B1n(:);
% An(end)    = A1n;
% vrn(:,end) = vr1n(:);
% vfn(:,end) = vf1n(:);   
    

num = length(Cexp);

Csim  = CB(1,ep(:));   % cfu/l
Csim2 = CB(2,ep(:));   % cfu/l
Csim3 = CB(3,ep(:));   % cfu/l
Csim4 = CB(4,ep(:));
Csim5 = CB(5,ep(:));
Csim6 = CB(6,ep(1:4));
Csim7 = CB(7,ep(1:3));
Csim8 = CB(8,ep(1:3));

Csim  = [repmat(Csim(1),3,1);repmat(Csim(2),3,1);repmat(Csim(3),3,1);repmat(Csim(4),3,1);repmat(Csim(5),3,1);repmat(Csim(6),3,1);repmat(Csim(7),3,1)]';
Csim2 = [repmat(Csim2(1),3,1);repmat(Csim2(2),3,1);repmat(Csim2(3),3,1);repmat(Csim2(4),3,1);repmat(Csim2(5),3,1);repmat(Csim2(6),3,1);repmat(Csim2(7),3,1)]';
Csim3 = [repmat(Csim3(1),3,1);repmat(Csim3(2),3,1);repmat(Csim3(3),3,1);repmat(Csim3(4),3,1);repmat(Csim3(5),3,1);repmat(Csim3(6),3,1);repmat(Csim3(7),3,1)]';
Csim4 = [repmat(Csim4(1),3,1);repmat(Csim4(2),3,1);repmat(Csim4(3),3,1);repmat(Csim4(4),3,1);repmat(Csim4(5),3,1);repmat(Csim4(6),3,1);repmat(Csim4(7),3,1)]';
Csim5 = [repmat(Csim5(1),3,1);repmat(Csim5(2),3,1);repmat(Csim5(3),3,1);repmat(Csim5(4),3,1);repmat(Csim5(5),3,1);repmat(Csim5(6),3,1);repmat(Csim5(7),3,1)]';
Csim6 = [repmat(Csim6(1),3,1);repmat(Csim6(2),3,1);repmat(Csim6(3),3,1);repmat(Csim6(4),3,1)]';
Csim7 = [repmat(Csim7(1),3,1);repmat(Csim7(2),3,1);repmat(Csim7(3),3,1)]';
Csim8 = [repmat(Csim8(1),3,1);repmat(Csim8(2),3,1);repmat(Csim8(3),3,1)]';

Cstot = [Csim,Csim2,Csim3,Csim4,Csim5,Csim6,Csim7,Csim8];   % cfu/l


     

%Cextot = [Cexp',Cexp2',Cexp3',Cexp4',Cexp5',Cexp6',Cexp7',];  % cfu/l   Experimental data from killing curves
% num2   = length(Cextot);

LCstot  = [log10(Csim),log10(Csim2),log10(Csim3),log10(Csim4),log10(Csim5),log10(Csim6),log10(Csim7),log10(Csim8)];
LCextot = [log10(Cexp(1,:)),log10(Cexp(2,:)),log10(Cexp(3,:)),log10(Cexp(4,:)),log10(Cexp(5,:)),log10(Cexp(6,1:12)),log10(Cexp(7,1:9)),log10(Cexp(8,1:9))];

%Cstot   = 10.^(LCstot);
Cextot  = 10.^(LCextot);

% 
% y0   = sum( sqrt((Csim(:) - Cexp(:)).^2)./Cexp(:) )*1/num; %C21

y = goodnessOfFit(LCextot,LCstot,'MSE'); % least squares sum((Cstot(:) - Cextot(:)).^2)


%sum( sqrt((Cstot(:) - Cextot(:)).^2)./Cextot(:) )*1/num2; %C21

% 
% ma  = max(sqrt((Csim(:) - Cexp(:)).^2)./Cexp(:));
% mal = max(sqrt((Csim(:) - Cexp(:)).^2)./Cexp(:));
% 

% 
% 
mdlog = fitlm(LCextot,LCstot);
% mdl = fitlm(Cstot(:),Cextot(:));
% 
R2a = mdlog.Rsquared.Adjusted;

% 
% v1=[mr7,y,X0];
%v1=[y,R2a,X0];

w = 10^(-3); % rescaling factor (from CFU/l to CFU/ml) 
trh = tr/3600; % time in hours

figure;semilogy(trh,w*CB(1,:),'c',t3exp/3600,w*Cexp(1,:),'c*',trh,w*CB(2,:),'m',t3exp/3600,w*Cexp(2,:),'*m',trh,w*CB(3,:),'y',t3exp/3600,w*Cexp(3,:),...
'y*',trh,w*CB(4,:),'r',t3exp/3600,w*Cexp(4,:),'r*',trh,w*CB(5,:),'g',t3exp/3600,w*Cexp(5,:),'g*',trh(1:3601),w*CB(6,1:3601),'b',t3exp(1:12)/3600,w*Cexp(6,1:12),'b*',...
trh(1:2401),w*CB(7,1:2401),'k',t3exp/3600,w*Cexp(7,:),'k*',trh(1:2401),w*CB(8,1:2401),'c',t3exp(:)/3600,w*Cexp(8,:),'c*','LineWidth',2)
xlabel('Time (hours)') 
ylabel('CFU/mL') 

% NG   = (log10(CB(:,end)) - log10(CB(:,1)) )/tr(end);
% NG1h = (log10(CB(:,61)) - log10(CB(:,1)) )/tr(61);
% z1 = zeros(1,nvm);
% figure;semilogx(vm,NG,vm,z1)
% 
% toc

%save 'Cipro_18h_paper_all_conc' 




